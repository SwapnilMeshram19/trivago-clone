
export const GET_ALL_CITIES = 'GET_ALL_CITIES'
