const HotelInfo=()=>{
    
    return (
        <div>

        </div>

    )
}

export default HotelInfo;