import React from 'react'
function Flights(){
    return(
        <>
        <h1>Flights</h1>
        </>
    )
}
export { Flights }