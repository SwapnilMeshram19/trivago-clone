import React from "react";
function Login (){
    return(
        <>
        <h1>Login</h1>
        </>
    )
}
export { Login }