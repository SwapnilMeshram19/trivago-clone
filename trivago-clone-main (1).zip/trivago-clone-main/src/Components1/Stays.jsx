import React from 'react'
function Stays(){
    return(
        <>
        <h1>stays</h1>
        </>
    )
}
export { Stays }