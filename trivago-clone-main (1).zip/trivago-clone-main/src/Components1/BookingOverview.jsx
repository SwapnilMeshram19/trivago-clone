import React from "react"
function BookingOverview(){
return(
    <>
    booking
    </>
)
}
export { BookingOverview }