import React from "react"
function Recently(){
return(
    <>
    recently
    </>
)
}
export { Recently }