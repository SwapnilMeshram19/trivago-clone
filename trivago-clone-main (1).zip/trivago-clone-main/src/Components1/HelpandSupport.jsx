import React from "react"
function HelpandSupport(){
return(
    <>
    help
    </>
)
}
export { HelpandSupport }