import React from 'react'
function Cars(){
    return(
        <>
        <h1>Cars</h1>
        </>
    )
}
export { Cars }