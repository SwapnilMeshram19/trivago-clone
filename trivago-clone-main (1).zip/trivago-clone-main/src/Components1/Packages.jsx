import React from 'react'
function Packages(){
    return(
        <>
        <h1>Packages</h1>
        </>
    )
}
export { Packages }